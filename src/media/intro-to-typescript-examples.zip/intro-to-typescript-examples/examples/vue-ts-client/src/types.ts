/* eslint-disable import/prefer-default-export */
/* eslint-disable import/no-relative-packages */

export type {
  default as ErrorResponse,
  // @ts-ignore
} from '../../express-api/src/interfaces/ErrorResponse';

export type {
  Todo,
  TodoWithId,
  // @ts-ignore
} from '../../express-api/src/api/todos/todos.model';
